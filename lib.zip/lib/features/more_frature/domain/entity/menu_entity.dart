class MenuEntity {
  final String content;

  MenuEntity({required this.content});
}
