import 'package:equatable/equatable.dart';
import 'product_entity.dart';

class ProductsPaginationEntity extends Equatable {
  final List<ProductEntity> products;
  final int page;
  final int pages;
  final int total;

  const ProductsPaginationEntity({
    required this.total,
    required this.products,
    required this.page,
    required this.pages,
  });

  @override
  List<Object?> get props => [products, page, pages,total];
}
