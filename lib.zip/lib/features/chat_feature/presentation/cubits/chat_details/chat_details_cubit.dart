import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mega_ecommerce_app/core/network/failures/failure.dart';
import 'package:mega_ecommerce_app/features/chat_feature/domain/entity/chat_details_entity.dart';
import 'package:mega_ecommerce_app/features/chat_feature/domain/use_cases/get_chat_details_use_case.dart';

part 'chat_details_state.dart';

class ChatDetailsCubit extends Cubit<IChatDetailsState> {
  final GetChatDetailsUseCase _getChatDetailsUseCase;

  ChatDetailsCubit(this._getChatDetailsUseCase) : super(ChatDetailsInitialState());

  Future<void> getChatDetails(String userId) async {
    emit(ChatDetailsLoadingState());
    final result = await _getChatDetailsUseCase(userId);
    result.fold(
      (failure) => emit(ChatDetailsFailureState(failure: failure)),
      (chatDetails) => emit(ChatDetailsSuccessState(chatDetails: chatDetails)),
    );
  }
}
