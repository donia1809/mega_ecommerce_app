class ApiConstants {
  static const baseUrl = "https://mega155-ecommerce-app-backend.vercel.app";
}